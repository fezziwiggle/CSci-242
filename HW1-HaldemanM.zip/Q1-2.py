
def MinMax(A,n):

    if n == 0:
        return A
    if n == 1:
        return A[0], A[0] 
    x = MinMax(A, n-1)
    return min(x[0], A[n-1]), max(x[1], A[n-1])  #recursive MinMax will repeat until n == 1, then starts at beginning of A and finds max between current element in A and the next element

A = [30,50,20,70,10,80,25,100,60,40]

n = 0
for i in A:
    n += 1

#print(n)

#print ("Calling MinMax")
a = MinMax(A,n)

print(a)

#In this case, you can't just modify the return value, but need to add at least a line of code so that it calls itself only once for each iteration