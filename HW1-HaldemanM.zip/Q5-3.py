def MinSubFastest(A):
    m = 0 #global minimum sum
    M = 0 #current minimum sum
    j = -1 #starting index
    k = -1 #ending index
    start = 0
    for t in range(0,n):
        M += A[t] #adds current element to current minimum sum
        if M < m:
            m = M
            j = start
            k = t
        if M > 0:
            M = 0
            start = t+1
    return m, j+1, k+1

A = [-2,-4,3,-1,5,6,-7,-2,4,-3,2]
B = [5,4,3,2,1,0,-1,-2,4,-4]

n = 0
for i in A:
    n += 1

o = MinSubFastest(A)

print(o)
