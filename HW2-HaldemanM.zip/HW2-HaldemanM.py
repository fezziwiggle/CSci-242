#Maezy Haldeman: maezy.haldeman@und.edu
#CSCI 242: Algorithms and Data Stuctures
#HW 2
#This program creates a binary search tree data structure and performs a number of operations to search and update the tree


class Node:
    
    def __init__(self, key, element):
        
        self.parent = None
        self.left = None
        self.right = None
        self.key = key
        self.element = element

    def Insert(self, k, e): 

        if self.key: #if true, the tree exists
            if k < self.key: #if true, we enter the left subtree
                if self.left is None: #if true, found location to insert
                    #self.left = Node(k,e)
                    temp = Node(k,e)
                    self.left = temp #this bit allows us to assign the parent before moving on
                    temp.parent = self
                else: #we haven't found location to insert, repeat
                    self.left.Insert(k,e)
            elif k > self.key: #if true, we enter the right subtree
                if self.right is None: #if true, found location to insert
                   # self.right = Node(k,e)
                    temp = Node(k,e)
                    self.right = temp
                    temp.parent = self
                else: #we haven't found location to insert, repeat
                    self.right.Insert(k,e)
        else: #tree doesn't exist, start a new one
            self.key = k

    def root(self):
       
        return self

    def Search(self, k, v):

        if k < v.key:
            if v.left is None:
                return 
            return v.left.Search(k,v.left)
        elif k > v.key:
            if v.right is None:
                return 
            return v.right.Search(k,v.right)
        else:
            return v 

    def Successor(self, v):
        
        if v is not None:
            if v.right is not None:
                return v.treeMinimum(v.right)
            parent = v.parent
            while(parent is not None):
                if v != parent.right:
                    break
                v = parent
                parent = parent.parent
            return parent

    def treeMinimum(self, v):

        current = v

        while current is not None:
            if current.left is None:
                break
            current = current.left

        return current

    def Predecessor(self, v):

        if v is not None:
            if v.left is not None:
                return v.treeMaximum(v.left)
            parent = v.parent
            while(parent is not None):
                if v != parent.left:
                    break
                v = parent
                parent = parent.parent
            return parent

    def treeMaximum(self, v):

        current = v

        while current is not None:
            if current.right is None:
                break
            current = current.right

        return current

    def removeAboveExternal(self, w):

        if w.left is None: #CASE 1 part 1: the left child of the node we are removing is external
            if w.isLeftChild(w):
                w.parent.left = w.right
                # if not w.isExternal:
                #     w.right.parent = w.parent
            elif w.isRightChild(w):
                w.parent.right = w.right
            if not w.isExternal(w):
                w.right.parent = w.parent
            w = None
        elif w.right is None: #CASE 1 part 2: the right child of the node we are removing is external
            if w.isLeftChild(w):
                w.parent.left = w.left
                # if not w.isExternal:
                #     w.left.parent = w.parent
            elif w.isRightChild(w):
                w.parent.right = w.left
            if not w.isExternal(w):
                w.left.parent = w.parent
            w = None

        elif w.left is not None and w.right is not None: #CASE 2: both children of the node we are removing are internals
            y = w.treeMinimum(w.right) # !!!! make sure this is what we want to use !!!!
            temp = w
            w.key = y.key
            w.element = y.element
            self.removeAboveExternal(y)

            return temp

    def Remove(self, k):

        #root = self
        v = self.Search(k,self)
        if v is not None:
            v.removeAboveExternal(v)
        else:
            print("Cannot remove a node not in the BST")

    def isRightChild(self, v): #determines if node passed to it is its parent's right child

        parent = v.parent

        if parent.right == v:
            return True
        else:
            return False

    def isLeftChild(self, v): #determines if node passed to it is its parent's left child

        parent = v.parent

        if parent.left == v:
            return True
        else:
            return False

    def isExternal(self, v): #determines if node passed is an external node

        if v is not None:
            if v.right is None and v.left is None:
                return True
            else:
                return False

    def isRoot(self, v):
        
        if v is not None:
            if v.parent is None:
                return True
            else:
                return False

    def LCA(self,v,w): #check all cases, make sure it's not incomplete

        if v is not None and w is not None: #catches the case where either v or w are not in the tree
            while v.depth(v) > w.depth(w):
                v = v.parent
            while w.depth(w) > v.depth(v):
                w = w.parent
            
            if v.depth(v) == w.depth(w):
                while v != w:
                    v = v.parent
                    w = w.parent
                if v == w:
                    LCA = v
                    return LCA
        else: #if v or w is not in the tree, return None
            return

    def depth(self, v):
        
        deep = 0
        while v.parent is not None:
            deep += 1
            v = v.parent

        return deep

    def rangeQuery(self,k1,k2,v):

        # if self.isExternal(v): #this is the textbook's algorithm
        #     return 
        # if k1 <= v.key <= k2:
        #     L = v.rangeQuery(k1,k2,v.left)
        #     R = v.rangeQuery(k1,k2,v.right)
        #     return L + v.key + R
        # elif v.key < k1:
        #     return v.rangeQuery(k1,k2,v.right)
        # elif k2 < v.key:
        #     return v.rangeQuery(k1,k2,v.left)

        if v is None:
            return

        if k1 < v.key:
            v.rangeQuery(k1,k2,v.left)
        if k1 <= v.key and k2 >= v.key:
            print (v.key)
        if k2 > v.key:
            v.rangeQuery(k1,k2,v.right)

    def numOfNodes(self, v):
        if not v:
            return 0
        return 1 + v.numOfNodes(v.left) + v.numOfNodes(v.right)

    def SelectL(self, i, v):

        if v is None:
            return
        
        while v:
            if (v.numOfNodes(v.right)+1) == i:
                return v.key
            elif i > v.numOfNodes(v.right)+1:
                i = i - ((v.numOfNodes(v.right))+1)
                v = v.left
            else:
                v = v.right
            

def InOrder(v):
    if v:
        InOrder(v.left)
        print(v.key)
        InOrder(v.right)
        
def PostOrder(v): 

    if v:
        PostOrder(v.left)
        PostOrder(v.right)
        print(v.key)

def main():

        BST = Node(25,'C') #testing Insert
        BST.Insert(35,'G')
        BST.Insert(45,'B')
        BST.Insert(20,'P')
        BST.Insert(30,'Q')
        BST.Insert(5,'Z')
        BST.Insert(55,'L')
        BST.Insert(43,'F')
        BST.Insert(22,'A')
        BST.Insert(6,'U')
        BST.Insert(8,'N')
        BST.Insert(40,'R')

        #testing InOrder
        print()
        print('In Order Traversal:') 
        InOrder(BST.root())

        #testing root
        print()
        item = BST.root() 
        print('Root:', item.key, item.element)

        #testing search
        print()
        v = BST.Search(45,BST.root())
        if v is not None: #search returns None if the node is not found, so we have to check before trying to print the key and element
            print("Search for node with key 45:", v.key, v.element)
        # print()
        # v = root.Search(11,root)
        # if v is not None:
        #     print("Search for node with key 11:", v.key, v.element)

        #testing successor
        print()
        v = BST.Search(8,BST.root())
        succ = BST.Successor(v)
        if succ is not None:
            print("Successor of node with key 8:", succ.key, succ.element)
        else:
            print("No successor of node with NoneType")
        v = BST.Search(35,BST.root())
        succ = BST.Successor(v)
        if succ is not None:
            print("Successor of node with key 35:", succ.key, succ.element)
        else:
            print("No successor of node with NoneType")
        # v = BST.Search(11,BST.root())
        # succ = BST.Successor(v)
        # if succ is not None:
        #     print("Successor of node with key 11:", succ.key, succ.element)
        # else:
        #     print("No successor of node with NoneType")

        #testing predecessor
        print()
        v = BST.Search(20,BST.root())
        pred = BST.Predecessor(v)
        if pred is not None:
            print("Predecessor of node with key 20:", pred.key, pred.element)
        else:
            print("No predecessor of node with NoneType")
        v = BST.Search(40,BST.root())
        pred = BST.Predecessor(v)
        if pred is not None:
            print("Predecessor of node with key 40:", pred.key, pred.element)
        else:
            print("No predecessor of node with NoneType")
        # v = BST.Search(11,BST.root())
        # pred = BST.Predecessor(v)
        # if pred is not None:
        #     print("Predecessor of node with key 11:", pred.key, pred.element)
        # else:
        #     print("No predecessor of node with NoneType")

        #testing remove (and removeAboveExternal) and PostOrder traversal
        print()
        BST.Remove(35)
        print("Post Order Traversal after removing 35:")
        PostOrder(BST.root())
        #InOrder(root)
        print()
        BST.Remove(5)
        print("Post Order Traversal after removing 5:")
        PostOrder(BST.root())
        #InOrder(root)
        # print()
        # BST.Remove(11)
        # print("Post Order Traversal after removing 11:")
        # PostOrder(BST.root())
        # #InOrder(root)

        #testing rangeQuery
        print()
        print("Range query in range [25,45]:")
        BST.rangeQuery(25,45,BST.root())
        print()
        print("Range query in range [10,40]:")
        BST.rangeQuery(10,40,BST.root())
        # print()
        # print("Range query in range [1,55] subtree rooted at 45:")
        # root.rangeQuery(1,55,root.right.right)

        #testing isExternal
        print()
        v = BST.Search(40,BST.root()) 
        print("Node with key 40 is external:", BST.isExternal(v))
        # print()
        # v = BST.Search(11,BST.root()) 
        # print("Node with key 11 is external:", BST.isExternal(v))

        #testing isRoot
        print()
        v = BST.Search(25,BST.root())
        print("Node with key 25 is root:", BST.isRoot(v))
        # v = BST.Search(40,BST.root())
        # print("Node with key 40 is root:", BST.isRoot(v))
      

        #testing LCA
        print() 
        v = BST.Search(30,BST.root())
        w = BST.Search(40,BST.root())
        LCAtemp = BST.LCA(v, w)
        if LCAtemp is None:
            print("No LCA of 30 and 40 because one of the keys passed is not in the BST")
        else:
            print("LCA of 30 and 40:",LCAtemp.key)

        print() 
        v = BST.Search(6,BST.root())
        w = BST.Search(55,BST.root())
        LCAtemp = BST.LCA(v, w)
        if LCAtemp is None:
            print("No LCA of 6 and 55 because one of the keys passed is not in the BST")
        else:
            print("LCA of 6 and 55:",LCAtemp.key)

        print() 
        v = BST.Search(35,BST.root())
        w = BST.Search(45,BST.root())
        LCAtemp = BST.LCA(v, w)
        if LCAtemp is None:
            print("No LCA of 35 and 45 because one of the keys passed is not in the BST")
        else:
            print("LCA of 35 and 45:",LCAtemp.key)

        # print()
        # v = BST.Search(25, BST.root())
        # print("Number of nodes in 25's left subtree:", BST.numOfNodes(v.left))
        # print("Number of nodes in 25's left subtree:", BST.numOfNodes(v.right))
        # print("Number of nodes in BST:", BST.numOfNodes(BST.root()))

        # InOrder(BST.root())

        print()
        print("8th largest key in BST:", BST.SelectL(8,BST.root()))

        # print()
        # print(BST.SelectL(0,BST.root()))

        print()


main()

